---
name: Intelligence Dark Mode
colors:
  surface: '#121317'
  surface-dim: '#121317'
  surface-bright: '#38393d'
  surface-container-lowest: '#0d0e12'
  surface-container-low: '#1a1b1f'
  surface-container: '#1e1f23'
  surface-container-high: '#292a2e'
  surface-container-highest: '#343539'
  on-surface: '#e3e2e7'
  on-surface-variant: '#c4c7c8'
  inverse-surface: '#e3e2e7'
  inverse-on-surface: '#2f3034'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c6c6c7'
  primary: '#ffffff'
  on-primary: '#2f3131'
  primary-container: '#e2e2e2'
  on-primary-container: '#636565'
  inverse-primary: '#5d5f5f'
  secondary: '#adc6ff'
  on-secondary: '#002e69'
  secondary-container: '#4b8eff'
  on-secondary-container: '#00285c'
  tertiary: '#ffffff'
  on-tertiary: '#003911'
  tertiary-container: '#72fe88'
  on-tertiary-container: '#00752b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c7'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a41'
  on-secondary-fixed-variant: '#004493'
  tertiary-fixed: '#72fe88'
  tertiary-fixed-dim: '#53e16f'
  on-tertiary-fixed: '#002107'
  on-tertiary-fixed-variant: '#00531c'
  background: '#121317'
  on-background: '#e3e2e7'
  surface-variant: '#343539'
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  data-mono:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1440px
  gutter: 24px
---

## Brand & Style
The design system is engineered to evoke a sense of absolute control and strategic clarity. It targets high-level decision-makers and power users who require high-fidelity data visualization without distractions. The aesthetic is a fusion of **Modern Corporate** and **HUD-inspired Minimalism**, focusing on technical precision rather than decorative flair. 

The emotional response is one of elite competence and surgical accuracy. Every pixel serves a functional purpose, utilizing heavy whitespace to separate complex data streams. The interface does not "greet" the user; it presents a high-performance environment for leverage and execution.

## Colors
The palette is strictly limited to maintain an authoritative tone. The foundation relies on a dual-black architecture: Deep Obsidian (#0D0D0D) for primary canvas areas and Charcoal (#1A1A1A) for elevated surfaces and containers. 

Surgical White (#FFFFFF) is reserved for primary text and high-priority interface actions. Slate Gray (#8E8E93) handles secondary information and non-active states. "Intelligence Blue" and "System Emerald" are used with extreme restraint—only appearing as single-pixel indicators, success labels, or active data pings. No gradients are permitted; all color transitions must be solid or defined by opacity steps.

## Typography
This design system utilizes **Inter** for all functional and narrative text to ensure maximum legibility at high densities. A strong hierarchy is established by contrasting bold, tight-tracked headings with smaller, well-spaced body copy.

For data points, metrics, and system status codes, **Space Grotesk** is used to provide a technical, monospaced feel that aligns with the HUD aesthetic. Use uppercase styling for labels and data points to reinforce the "command centre" atmosphere. Alignment must be rigorous; text should snap to a strict baseline grid to maintain the elite, structured tone.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy within a 12-column system, maximizing horizontal real estate while maintaining generous outer margins (40px+) to frame the content. 

Information density is high, but legibility is preserved through an 8px spacing rhythm. Gutters are kept narrow (24px) to allow data clusters to feel unified. Elements should be aligned to the edges of columns with mathematical precision. Use "negative space" as a functional separator rather than relying on heavy graphic dividers.

## Elevation & Depth
In this design system, depth is achieved through **Tonal Layers** and **Low-Contrast Outlines** rather than shadows. Surfaces do not float; they are seated within the canvas. 

The base background is Obsidian. Secondary containers (cards, sidebars) use Charcoal with a 1px hairline border in `white / 10% opacity`. This creates a subtle "etched" look characteristic of high-end hardware interfaces. Active states may use a slightly brighter border (20% opacity) or a singular 2px accent line on the left or top edge of the component.

## Shapes
The shape language is strictly **Sharp (0px)**. All containers, buttons, and input fields feature 90-degree corners. This evokes a sense of rigid, uncompromising structural integrity. Avoid any rounding, as it diminishes the professional, tactical nature of the command centre aesthetic. The only exception is the interior of circular progress indicators, which must remain geometric circles.

## Components
- **Buttons:** Rectangular with no radius. Primary buttons are solid White with Black text. Secondary buttons are transparent with a 1px White hairline border. No hover transitions should involve "bouncing"—only immediate opacity shifts.
- **HUD Cards:** Charcoal background, 1px border. Titles should be in `label-caps` typography, often accompanied by a monospaced "System ID" or timestamp in the top-right corner.
- **Data Tables:** High-density, no vertical lines. Horizontal lines should be `white / 5% opacity`. Header cells use `label-caps` with Slate Gray text. 
- **Progress Bars:** Monochromatic. The track is `white / 10%`, and the fill is solid White or System Emerald for success states. 100% flat—no glows or gradients.
- **Input Fields:** Bottom-border only or full hairline border. Placeholder text in Slate Gray. Active focus is indicated by a shift to solid White border.
- **System Metrics:** Use Space Grotesk for numerical values. Large "Hero Metrics" should be bold and accompanied by a small trend indicator (e.g., a simple 45-degree arrow, no curves).
- **Status Pips:** Small 6px squares (not circles) used to indicate "Live" or "Active" statuses, utilizing Intelligence Blue or System Emerald.